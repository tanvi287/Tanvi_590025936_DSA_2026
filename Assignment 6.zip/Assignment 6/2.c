#include <stdio.h>

int heap[100];
int size = 0;

void swap(int *a, int *b)
{
    int t = *a;
    *a = *b;
    *b = t;
}

void insert(int val)
{
    heap[++size] = val;
    int i = size;

    while(i > 1 && heap[i] < heap[i/2])
    {
        swap(&heap[i], &heap[i/2]);
        i = i/2;
    }
}

void delete()
{
    heap[1] = heap[size--];
    int i = 1;

    while(2*i <= size)
    {
        int small = 2*i;
        if(2*i+1 <= size && heap[2*i+1] < heap[2*i])
            small = 2*i+1;

        if(heap[i] > heap[small])
        {
            swap(&heap[i], &heap[small]);
            i = small;
        }
        else break;
    }
}

void display()
{
    for(int i=1;i<=size;i++)
        printf("%d ", heap[i]);
}

int main()
{
    insert(50);
    insert(30);
    insert(20);
    insert(40);

    display();

    delete();

    printf("\nAfter delete:\n");
    display();

    return 0;
}
