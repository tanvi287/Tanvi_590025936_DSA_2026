#include <stdio.h>

int pq[100];
int size = 0;

void swap(int *a, int *b)
{
    int t = *a;
    *a = *b;
    *b = t;
}

void insert(int val)
{
    pq[++size] = val;
    int i = size;

    while(i > 1 && pq[i] < pq[i/2])
    {
        swap(&pq[i], &pq[i/2]);
        i = i/2;
    }
}

void delete()
{
    pq[1] = pq[size--];
    int i = 1;

    while(2*i <= size)
    {
        int small = 2*i;
        if(2*i+1 <= size && pq[2*i+1] < pq[2*i])
            small = 2*i+1;

        if(pq[i] > pq[small])
        {
            swap(&pq[i], &pq[small]);
            i = small;
        }
        else break;
    }
}

void peek()
{
    if(size > 0)
        printf("Top: %d\n", pq[1]);
}

void display()
{
    for(int i=1;i<=size;i++)
        printf("%d ", pq[i]);
}

int main()
{
    insert(40);
    insert(10);
    insert(30);
    insert(20);

    peek();
    display();

    delete();

    printf("\nAfter delete:\n");
    display();

    return 0;
}
