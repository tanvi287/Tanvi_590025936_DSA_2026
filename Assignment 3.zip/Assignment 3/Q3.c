#include <stdio.h>
#include <string.h>

int main() {
    char str[50], s[50];
    int top = -1;

    printf("Enter string: ");
    scanf("%s", str);

    for (int i = 0; i < strlen(str); i++) {
        s[++top] = str[i];
    }

    printf("Reversed string: ");
    while (top != -1) {
        printf("%c", s[top--]);
    }

    return 0;
}
