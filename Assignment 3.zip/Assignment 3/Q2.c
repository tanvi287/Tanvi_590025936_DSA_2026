#include <stdio.h>
#include <stdlib.h>

struct node {
    int data;
    struct node *next;
};

struct node *top = NULL;

void push() {
    struct node *newnode;
    newnode = (struct node*)malloc(sizeof(struct node));

    printf("Enter value: ");
    scanf("%d", &newnode->data);

    newnode->next = top;
    top = newnode;
}

void pop() {
    struct node *temp;

    if (top == NULL) {
        printf("Stack Empty\n");
    } else {
        temp = top;
        printf("Deleted: %d\n", temp->data);
        top = top->next;
        free(temp);
    }
}

void display() {
    struct node *temp = top;

    if (top == NULL) {
        printf("Empty Stack\n");
    } else {
        while (temp != NULL) {
            printf("%d\n", temp->data);
            temp = temp->next;
        }
    }
}

int main() {
    int ch;

    printf("1.Push\n2.Pop\n3.Display\n4.Exit\n");

    while (1) {
        printf("Enter choice: ");
        scanf("%d", &ch);

        switch (ch) {
            case 1: push(); break;
            case 2: pop(); break;
            case 3: display(); break;
            case 4: return 0;
            default: printf("Invalid choice\n");
        }
    }
}
