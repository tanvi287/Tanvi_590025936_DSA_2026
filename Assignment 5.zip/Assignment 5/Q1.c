#include <stdio.h>

int tree[100];

void insert(int i, int val)
{
    tree[i] = val;
}

void display(int n)
{
    for(int i = 1; i <= n; i++)
    {
        if(tree[i] != 0)
            printf("%d ", tree[i]);
    }
}

void relations(int i)
{
    printf("Node: %d\n", tree[i]);

    if(i/2 >= 1)
        printf("Parent: %d\n", tree[i/2]);

    if(2*i < 100 && tree[2*i] != 0)
        printf("Left Child: %d\n", tree[2*i]);

    if(2*i+1 < 100 && tree[2*i+1] != 0)
        printf("Right Child: %d\n", tree[2*i+1]);
}

int main()
{
    int n, val;

    printf("Enter number of nodes: ");
    scanf("%d", &n);

    for(int i = 1; i <= n; i++)
    {
        scanf("%d", &val);
        insert(i, val);
    }

    display(n);

    int index;
    printf("\nEnter index: ");
    scanf("%d", &index);

    relations(index);

    return 0;
}
