#include <stdio.h>
#include <stdlib.h>

struct node{
	int data;
	struct node *next;
};

int main(){
	int ch,n,i,value,count;
	struct node *head=NULL,*last=NULL,*temp,*newnode,*prev;
	
	while(1){
		printf("\n1.Create");
		printf("\n2.Insert at Beginning");
		printf("\n3.Insert at End");
		printf("\n4.Delete from Beginning");
		printf("\n5.Delete from End");
		printf("\n6.Display & Count");
		printf("\n7.Exit");
		printf("\nEnter choice:");
		scanf("%d",&ch);
		
		/* CREATE */
		if(ch==1){
			printf("Enter number of nodes:");
			scanf("%d",&n);
			
			for(i=0;i<n;i++){
				printf("Enter data:");
				scanf("%d",&value);
				
				newnode=(struct node*)malloc(sizeof(struct node));
				newnode->data=value;
				
				if(head==NULL){
					head=newnode;
					newnode->next=head;
					last=newnode;
				}
				else{
					newnode->next=head;
					last->next=newnode;
					last=newnode;
				}
			}
		}
		
		/* INSERT AT BEGINNING */
		else if(ch==2){
			printf("Enter value:");
			scanf("%d",&value);
			
			newnode=(struct node*)malloc(sizeof(struct node));
			newnode->data=value;
			
			if(head==NULL){
				head=newnode;
				newnode->next=head;
				last=newnode;
			}
			else{
				newnode->next=head;
				last->next=newnode;
				head=newnode;
			}
		}
		
		/* INSERT AT END */
		else if(ch==3){
			printf("Enter value:");
			scanf("%d",&value);
			
			newnode=(struct node*)malloc(sizeof(struct node));
			newnode->data=value;
			
			if(head==NULL){
				head=newnode;
				newnode->next=head;
				last=newnode;
			}
			else{
				newnode->next=head;
				last->next=newnode;
				last=newnode;
			}
		}
		
		/* DELETE FROM BEGINNING */
		else if(ch==4){
			if(head==NULL)
			printf("List is empty");
			else if(head==last){
				free(head);
				head=last=NULL;
			}
			else{
				temp=head;
				head=head->next;
				last->next=head;
				free(temp);
			}
		}
		
		/* DELETE FROM END */
		else if(ch==5){
			if(head==NULL)
			printf("List is empty");
			else if(head==last){
				free(head);
				head=last=NULL;
			}
			else{
				temp=head;
				while(temp->next!=last)
				temp=temp->next;
				
				temp->next=head;
				free(last);
				last=temp;
			}
		}
		
		/* DISPLAY AND COUNT */
		else if(ch==6){
			if(head==NULL)
			printf("List is empty");
			else{
				temp=head;
				count=0;
				printf("Circular List:\n");
				do{
					printf("%d ",temp->data);
					temp=temp->next;
					count++;
				}while(temp!=head);
				
				printf("\nTotal nodes:%d",count);
			}
		}
		else if(ch==7)
		break;
		
		else
		printf("Invalid choice");
	}
	return 0;
}
