#include <stdio.h>
#include <stdlib.h>

struct node{
    int data;
    struct node *prev;
    struct node *next;
};

int main(){

    int ch,n,i,value,key,count;
    struct node *head=NULL,*temp,*newnode,*last,*del;

    while(1){

        printf("\n1.Create");
        printf("\n2.Insert at Beginning");
        printf("\n3.Insert at End");
        printf("\n4.Insert After Given Node");
        printf("\n5.Delete from Beginning");
        printf("\n6.Delete from End");
        printf("\n7.Delete Given Node");
        printf("\n8.Display and Count");
        printf("\n9.Traverse (Forward & Backward)");
        printf("\n10.Exit");
        printf("\nEnter choice: ");
        scanf("%d",&ch);

        /* CREATE */
        if(ch==1){

            printf("Enter number of nodes: ");
            scanf("%d",&n);

            for(i=0;i<n;i++){

                printf("Enter data: ");
                scanf("%d",&value);

                newnode=(struct node*)malloc(sizeof(struct node));
                newnode->data=value;
                newnode->prev=NULL;
                newnode->next=NULL;

                if(head==NULL){
                    head=newnode;
                    last=newnode;
                }
                else{
                    last->next=newnode;
                    newnode->prev=last;
                    last=newnode;
                }
            }
        }

        /* INSERT AT BEGINNING */
        else if(ch==2){

            printf("Enter value: ");
            scanf("%d",&value);

            newnode=(struct node*)malloc(sizeof(struct node));
            newnode->data=value;
            newnode->prev=NULL;
            newnode->next=head;

            if(head!=NULL)
                head->prev=newnode;

            head=newnode;
        }

        /* INSERT AT END */
        else if(ch==3){

            printf("Enter value: ");
            scanf("%d",&value);

            newnode=(struct node*)malloc(sizeof(struct node));
            newnode->data=value;
            newnode->next=NULL;

            if(head==NULL){
                newnode->prev=NULL;
                head=newnode;
            }
            else{
                temp=head;
                while(temp->next!=NULL)
                    temp=temp->next;

                temp->next=newnode;
                newnode->prev=temp;
            }
        }

        /* INSERT AFTER GIVEN NODE */
        else if(ch==4){

            printf("Enter key: ");
            scanf("%d",&key);

            printf("Enter value: ");
            scanf("%d",&value);

            temp=head;

            while(temp!=NULL && temp->data!=key)
                temp=temp->next;

            if(temp==NULL)
                printf("Node not found");
            else{
                newnode=(struct node*)malloc(sizeof(struct node));
                newnode->data=value;

                newnode->next=temp->next;
                newnode->prev=temp;

                if(temp->next!=NULL)
                    temp->next->prev=newnode;

                temp->next=newnode;
            }
        }

        /* DELETE FROM BEGINNING */
        else if(ch==5){

            if(head==NULL)
                printf("List is empty");
            else{
                del=head;
                head=head->next;

                if(head!=NULL)
                    head->prev=NULL;

                free(del);
            }
        }

        /* DELETE FROM END */
        else if(ch==6){

            if(head==NULL)
                printf("List is empty");
            else{
                temp=head;

                while(temp->next!=NULL)
                    temp=temp->next;

                if(temp->prev!=NULL)
                    temp->prev->next=NULL;
                else
                    head=NULL;

                free(temp);
            }
        }

        /* DELETE GIVEN NODE */
        else if(ch==7){

            printf("Enter key: ");
            scanf("%d",&key);

            temp=head;

            while(temp!=NULL && temp->data!=key)
                temp=temp->next;

            if(temp==NULL)
                printf("Node not found");
            else{

                if(temp->prev!=NULL)
                    temp->prev->next=temp->next;
                else
                    head=temp->next;

                if(temp->next!=NULL)
                    temp->next->prev=temp->prev;

                free(temp);
            }
        }

        /* DISPLAY AND COUNT */
        else if(ch==8){

            temp=head;
            count=0;

            while(temp!=NULL){
                printf("%d ",temp->data);
                count++;
                temp=temp->next;
            }

            printf("\nTotal nodes: %d",count);
        }

        /* FORWARD & BACKWARD TRAVERSAL */
        else if(ch==9){

            if(head==NULL)
                printf("List is empty");
            else{

                temp=head;

                printf("Forward: ");
                while(temp->next!=NULL){
                    printf("%d ",temp->data);
                    temp=temp->next;
                }
                printf("%d",temp->data);

                printf("\nBackward: ");
                while(temp!=NULL){
                    printf("%d ",temp->data);
                    temp=temp->prev;
                }
            }
        }

        else if(ch==10)
            break;

        else
            printf("Invalid choice");
    }

    return 0;
}
