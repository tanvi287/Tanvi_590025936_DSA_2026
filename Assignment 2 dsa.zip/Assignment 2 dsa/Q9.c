#include <stdio.h>
#include <stdlib.h>
#include <math.h>

struct node{
	int coef;
	int exp;
	struct node *next;
};

int main(){
	int n,i,x;
	float result=0;
	struct node *head=NULL,*temp=NULL,*newnode;
	
	printf("Enter number of terms:");
	scanf("%d",&n);
	
	for(i=0;i<n;i++)
	{
		newnode=(struct node*)malloc(sizeof(struct node));  // create node
		
		printf("Enter coefficient:");
		scanf("%d",&newnode->coef);
		
		printf("Enter exponent:");
		scanf("%d",&newnode->exp);
		
		newnode->next=NULL;
		
		if(head==NULL)
		{
			head=newnode;   // first term
			temp=newnode;
		}
		else
		{
			temp->next=newnode;   // link term
			temp=newnode;
		}
	}
	
	printf("Enter value of x:");
	scanf("%d",&x);
	
	temp=head;
	while(temp!=NULL)
	{
		result=result + temp->coef * pow(x,temp->exp);  // evaluate term
		temp=temp->next;
	}
	
	printf("Result of polynomial:%0.2f",result);
	
	return 0;
}
