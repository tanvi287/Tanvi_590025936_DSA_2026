#include <stdio.h>
#include <stdlib.h>

struct node{
	int data;
	struct node *next;
};

int main(){
	int i,n,value,newvalue;
	struct node *head=NULL,*temp=NULL,*newnode;
	
	printf("Enter number of nodes:");
	scanf("%d",&n);
	
	for(i=0;i<n;i++)
	{
		printf("Enter data:");
		scanf("%d",&value);
		
		newnode=(struct node*)malloc(sizeof(struct node));  // create node
		newnode->data=value;
		newnode->next=NULL;
		
		if(head==NULL)
		{
			head=newnode;      // first node
			temp=newnode;
		}
		else
		{
			temp->next=newnode;  // link node
			temp=newnode;
		}
	}
	
	printf("Enter element to insert at end:");
	scanf("%d",&newvalue);
	
	newnode=(struct node*)malloc(sizeof(struct node));  // create new node
	newnode->data=newvalue;
	newnode->next=NULL;
	
	if(head==NULL)
	{
		head=newnode;   // if list empty
	}
	else
	{
		temp=head;
		while(temp->next!=NULL)   // move to last node
		temp=temp->next;
		
		temp->next=newnode;   // attach at end
	}
	
	printf("Linked list after insertion:\n");
	temp=head;   // traversal
	
	while(temp!=NULL)
	{
		printf("%d ",temp->data);
		temp=temp->next;
	}
	return 0;
}
