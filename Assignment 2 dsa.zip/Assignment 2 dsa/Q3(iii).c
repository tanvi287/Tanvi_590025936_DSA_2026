#include <stdio.h>
#include <stdlib.h>

struct node{
	int data;
	struct node *next;
};

int main(){
	int i,n,value,key,newvalue,found=0;
	struct node *head=NULL,*temp=NULL,*newnode;
	
	printf("Enter number of nodes:");
	scanf("%d",&n);
	
	for(i=0;i<n;i++)
	{
		printf("Enter data:");
		scanf("%d",&value);
		
		newnode=(struct node*)malloc(sizeof(struct node));  // create node
		newnode->data=value;
		newnode->next=NULL;
		
		if(head==NULL)
		{
			head=newnode;   // first node
			temp=newnode;
		}
		else
		{
			temp->next=newnode;   // link node
			temp=newnode;
		}
	}
	
	printf("Enter element after which to insert:");
	scanf("%d",&key);	
	printf("Enter new value:");
	scanf("%d",&newvalue);
	temp=head;   // start searching
	while(temp!=NULL)
	{
		if(temp->data==key)
		{
			found=1;
			break;
		}
		temp=temp->next;
	}
	
	if(found==1)
	{
		newnode=(struct node*)malloc(sizeof(struct node));  // create new node
		newnode->data=newvalue;
		newnode->next=temp->next;   // link to next node
		temp->next=newnode;         // insert after key
		
		printf("Linked list after insertion:\n");
		temp=head;
		while(temp!=NULL)
		{
			printf("%d ",temp->data);
			temp=temp->next;
		}
	}
	else
	printf("Given node not found");
	
	return 0;
}
