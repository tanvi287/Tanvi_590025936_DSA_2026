#include <stdio.h>
#include <stdlib.h>

struct node{
	int data;
	struct node *next;
};

int main(){
	int i,n,value,key,found=0;
	struct node *head=NULL,*temp=NULL,*deleteNode,*newnode;
	
	printf("Enter number of nodes:");
	scanf("%d",&n);
	
	for(i=0;i<n;i++)
	{
		printf("Enter data:");
		scanf("%d",&value);
		
		newnode=(struct node*)malloc(sizeof(struct node));  // create node
		newnode->data=value;
		newnode->next=NULL;
		
		if(head==NULL)
		{
			head=newnode;   // first node
			temp=newnode;
		}
		else
		{
			temp->next=newnode;   // link node
			temp=newnode;
		}
	}
	
	printf("Enter value after which node should be deleted:");
	scanf("%d",&key);
	
	temp=head;   // start searching
	
	while(temp!=NULL)
	{
		if(temp->data==key)
		{
			found=1;
			break;
		}
		temp=temp->next;
	}
	
	if(found==0)
	{
		printf("Given node not found");
	}
	else if(temp->next==NULL)
	{
		printf("No node exists after the given node");
	}
	else
	{
		deleteNode=temp->next;      // node to delete
		temp->next=deleteNode->next;  // bypass node
		free(deleteNode);            // free memory
		
		printf("Linked list after deletion:\n");
		temp=head;
		
		while(temp!=NULL)
		{
			printf("%d ",temp->data);
			temp=temp->next;
		}
	}	
	return 0;
}
