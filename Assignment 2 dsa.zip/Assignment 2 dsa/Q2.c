#include <stdio.h>
#include <stdlib.h>

struct node{
	int data;
	struct node *next;
};

int main(){
	int i,n,value,search,pos=1,found=0;   // pos for position
	struct node *head=NULL,*temp=NULL,*newnode;
	
	printf("Enter number of nodes:");
	scanf("%d",&n);
	
	for(i=0;i<n;i++)
	{
		printf("Enter data:");
		scanf("%d",&value);
		
		newnode=(struct node*)malloc(sizeof(struct node));  // create node
		newnode->data=value;
		newnode->next=NULL;
		
		if(head==NULL)
		{
			head=newnode;      // first node
			temp=newnode;
		}
		else
		{
			temp->next=newnode;  // link node
			temp=newnode;
		}
	}
	printf("Enter element to search:");
	scanf("%d",&search);
	
	temp=head;   // start traversal
	
	while(temp!=NULL)
	{
		if(temp->data==search)
		{
			found=1;
			break;
		}
		temp=temp->next;
		pos++;   // move position
	}
	if(found==1)
	printf("Element found at position:%d",pos);
	else
	printf("Element does not exist");	
	return 0;
}
