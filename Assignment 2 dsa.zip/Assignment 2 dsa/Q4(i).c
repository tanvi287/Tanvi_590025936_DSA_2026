#include <stdio.h>
#include <stdlib.h>

struct node{
	int data;
	struct node *next;
};

int main(){
	int i,n,value;
	struct node *head=NULL,*temp=NULL,*prev=NULL,*newnode;
	
	printf("Enter number of nodes:");
	scanf("%d",&n);
	
	for(i=0;i<n;i++)
	{
		printf("Enter data:");
		scanf("%d",&value);
		
		newnode=(struct node*)malloc(sizeof(struct node));  // create node
		newnode->data=value;
		newnode->next=NULL;
		
		if(head==NULL)
		{
			head=newnode;   // first node
			temp=newnode;
		}
		else
		{
			temp->next=newnode;   // link node
			temp=newnode;
		}
	}	
	if(head==NULL)
	{
		printf("List is empty");
	}
	else if(head->next==NULL)
	{
		free(head);     // only one node
		head=NULL;
	}
	else
	{
		temp=head;
		
		while(temp->next!=NULL)   // move to last node
		{
			prev=temp;            // store previous node
			temp=temp->next;
		}
		
		prev->next=NULL;   // remove last node link
		free(temp);        // delete last node
	}
	
	printf("Linked list after deletion:\n");
	temp=head;
	
	while(temp!=NULL)
	{
		printf("%d ",temp->data);
		temp=temp->next;
	}	
	return 0;
}
